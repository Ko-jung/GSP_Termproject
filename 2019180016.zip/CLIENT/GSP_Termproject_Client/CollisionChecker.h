#pragma once

#include "Define.h"
#include "framework.h"

class CollisionChecker
{
public:
public:
	SINGTON(CollisionChecker);

	static bool CollisionCheck(const RECT& a, const RECT& b);
};

